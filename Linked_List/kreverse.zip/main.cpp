/******************************************************************************

*******************************************************************************/
#include <iostream>
using namespace std;
node* kreverse(node* head, int k){
    if(head == NULL){
        return NULL;
    }
    node* next = NULL;
    node* curr = head;
    node* prev = NULL;
    int cnt=0;
    while(curr != NULL && cnt < k){
        next = curr -> next;
        curr -> next = prev;
        prev = curr;
        curr = next;
        cnt++;
    }
    if(next != NULL){
        head -> next = kreverse(next, k);
    }
    return prev;
}





































node* kreverse(node* head, int k){
    if(head == NULL)return NULL;
    node* next = NULL;
    node* curr = head;
    node* prev = NULL;
    int cnt=0;
    while(curr != NULL && k < cnt){
        next=curr -> next;//first node
        curr -> next = prev;// null
        prev = curr;//head
        curr = curr -> next;//one step increase
        cnt++;
    }
    if(next != NULL){
        head -> next = kreverse(next, k);
    }
    return prev;
}
































node* kreverse(node* head, int k){
    if(head == NULL) return NULL;
    node* next =NULL;
    node* curr = head;
    node* prev = NULL;
    int cnt=0;
    while(curr != NULL && cnt < k){
        next = curr -> next;
        curr -> next = prev;
        prev = curr;
        curr= curr -> next;
        cnt++;
    }
    if(next != NULL)head-> next = kreverse(next , k);
    return prev;
}






























node* kreverse(node* head){
    if(head==NULL)return NULL;
    node* prev =NULL;
    node* curr = head;
    node* next = NULL;
    int cnt=0;
    while(curr != NULL && cnt<k){
        next = curr -> next;
        curr -> next = prev;
        prev = curr;
        curr = curr -> next;
        cnt++;
    }
    if(next != NULL)head-> next = kreverse(next , k);
    return prev;
}




























node* kreverse(node* head){
    if(head==NULL)return NULL;
    node* prev = NULL;
    node* curr = head;
    node* next=NULL;
    int cnt=0;
    while(curr != NULL && cnt < k){
        next = curr -> next;
        curr -> next =prev;
        prev=curr;
        curr= curr -> next;
        cnt++;
    }
    if(next!=NULL)head -> next = kreverse(next ,k );
    return prev;
}

int main()
{
    cout<<"Hello World";

    return 0;
}