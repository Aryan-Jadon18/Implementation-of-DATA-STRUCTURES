/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class node{
    public:
    int data;
    node* next;
    //constructor
    node(int data){
        this->data=data;
        this->next=NULL;
    }
    //destructor
    ~node(){
        int value=this->data;
        //memory free
        if(this->next !=NULL){
            delete next;
            this -> next = NULL;
        }
    }
};
void insertathead(node* &head, int d){
    node* temp= new node(d);
    temp->next=head;
    head=temp;
}
void insertattail(node* &tail, int d){
    node* temp= new node(d);
    tail -> next= temp;
    tail = temp;
}
void insertatposition(node* &head, int position, int d){
    node* temp=head;
    if(position==1){
        insertathead(head, d);
    }
    int cnt=1;
    while(cnt <position -1){
        temp= temp -> next;
        cnt++;
    }
    node* nodetoinsert= new node(d);
    nodetoinsert -> next = temp -> next;
    temp -> next= nodetoinsert;
}
void deletenode(node* &head,int position){
    //deleting start node
    if(position == 1){
        node* temp= head;
        head=head -> next;
        //memory free start node
        delete temp;
    }
    else{
        //deleting any node
        node* curr = head;
        node* prev=NULL;
        int cnt=1;
        while(cnt <= position){
            prev = curr;
            curr = curr -> next;
            cnt++;
        }
        prev -> next = curr -> next;
        curr -> next = NULL;
        delete curr;
    }
}
void print(node* &head){
    node* temp=head;
    while(temp!=NULL){
        cout << temp->data << " ";
        temp=temp->next;
    }
    cout<<endl;
}

int main()
{
    node* node1=new node(10);
    node* head=node1;
    node* tail=node1;
    insertattail(tail,124);
    insertathead(head,12);
    insertathead(head,108);
    insertatposition(head,3,22);
    //deletenode(head,4);
    print(head);    
    return 0;
}

