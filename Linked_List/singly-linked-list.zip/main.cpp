#include <iostream>
using namespace std;
class node{
    public:
    int data;
    node* next;
    node(int d){
        this -> data=d;
        this -> next=NULL;
    }
};

void insertathead(node* &head, int d){
    node* temp =new node(d);
    temp -> next =head;
    head = temp;
}



void insertattail(node* &tail, int d){
    node* temp = new node(d);
    tail = temp -> next;
    tail = temp;
}



void insertatpos(node* &tail, node* &head, int pos,int d){
    if(pos==1){
        insertathead(head,d);
        return;
    }
    node* temp =head;
    int cnt=1;
    while(cnt<pos-1){
        temp = temp -> next;
        cnt++;
    }
    if(temp -> next==NULL){
        insertattail(tail,d);
        return;
    }
    //creating a node for d
    node* nodetoinsert=new node(d);
    nodetoinsert -> next = temp -> next;
    temp -> next= nodetoinsert;
}




void print(node* &head){
    if(head ==  NULL){
        cout<<"List is empty: "<<endl;
        return;
    }
    node* temp= head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp = temp -> next;
    }
    cout<<endl;
}


void deletenode(int position, node* &head){
    if(position == 1){//first position
        node* temp = head;//create temp
        head = head -> next;//move head
        temp -> next = NULL;//disconnet temp
        delete temp;//delete temp
    }else{
        node* curr = head;//to be deleted
        node* prev = NULL;//to be connected
        int cnt=1;//counter
        while(cnt<position){
            prev = curr;// (h)(p)1->(c)2->3->4->5
            curr = curr -> next;//
            cnt++;//counter++
        }//reached the target
        prev -> next = curr -> next;//connect prev to curr->next
        curr -> next = NULL;//disconnect curr
        delete curr;//remove curr
    }
}

bool iscircularlist(node* &head){
    //empty
    if(head == NULL){
        return true;
    }
    node* temp= head -> next;//1st node
    while(temp!= NULL && temp != head){
        temp = temp -> next;//move forward
    }
    if(temp == head){//reached head again
        return true;
    }
    return false;
}
node* kreverse(node* head, int k){
    if(head == NULL) return NULL;
    node* prev = NULL;
    node* curr =head;
    node* next = NULL;
    int cnt=0;
    while(curr != NULL && cnt<k){
        next = curr -> next;
        curr -> next = prev;
        prev = curr;
        curr = next;
        cnt++;
    }
    if(next!=NULL)head -> next = kreverse(next,k);
    return prev;
}
int main()
{
    node* node1 = new node(10);
    node* head = node1;
    node* tail = node1;
    print(head);
    insertathead(head,12);
    insertathead(head,14);
    print(head);
    insertattail(tail,15);
    print(head);
    insertatpos(tail, head, 2, 22);
    print(head);
    deletenode(2,head);
    print(head);
    return 0;
}
